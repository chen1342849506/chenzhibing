package com.longshare.fm.otc.systemic.orm.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author liyou
 * @Date: 2020-03-30 17:05
 */

@Getter
@Setter
@ToString
public class BankInfoQueryBean {
	//银行序号列表
	private List<Integer> bankIds;
	//关键字
	private String keyWord;
}
