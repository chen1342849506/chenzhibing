package com.longshare.fm.otc.systemic.model.vo;


import com.longshare.fm.otc.systemic.service.dto.BankInfo;
import com.longshare.fm.otc.systemic.service.dto.BankInfoListQueryOut;
import com.longshare.fm.otc.systemic.service.dto.IssuerListInfo;
import com.longshare.fm.otc.systemic.service.dto.IssuerListQueryOut;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class BankInfoListQueryResult {

    //银行序号
    private List<BankVo> bankIofoList;

    public BankInfoListQueryResult(BankInfoListQueryOut bankInfoListQueryOut) {
        List<BankVo> bankIofoListVos = new ArrayList<>();
        if (bankInfoListQueryOut.getBankIofoList() != null){
            for (BankInfo bankInfo  : bankInfoListQueryOut.getBankIofoList()){
                bankIofoListVos.add(new BankVo(bankInfo));
            }
        }
        this.bankIofoList = bankIofoListVos;

    }
}
