package com.longshare.fm.otc.systemic.model.vo;


import com.longshare.fm.otc.systemic.service.dto.BankInfoListQueryIn;
import com.longshare.microservice.ots.biz.core.model.common.OtcPageParam;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BankInfoListQueryParam extends OtcPageParam {

    //银行序号
    private String bankId;
    //关键字
    private String keyWord;

    public BankInfoListQueryIn paramToIn(){
        BankInfoListQueryIn queryBankInfoListIn = new BankInfoListQueryIn();
        queryBankInfoListIn.setBankId(this.bankId);
        queryBankInfoListIn.setKeyWord(this.keyWord);
        return queryBankInfoListIn;
    }


}
