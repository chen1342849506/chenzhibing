package com.longshare.fm.otc.systemic.model.vo;


import com.longshare.fm.otc.systemic.service.dto.BankInfo;
import com.longshare.microservice.ots.biz.core.utils.StringUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BankVo {

    //银行序号
    private String bankId;
    //发行人序号
    private String issuerId;
    //银行代码
    private String bankCode;
    //银行名称
    private String bankName;

    public BankVo (BankInfo bankInfo){
        this.bankId = StringUtils.toString(bankInfo.getBankId());
        this.issuerId = StringUtils.toString(bankInfo.getIssuerId());
        this.bankCode = bankInfo.getBankCode();
        this.bankName = bankInfo.getBankName();
    }
}
