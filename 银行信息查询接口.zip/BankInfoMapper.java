package com.longshare.fm.otc.systemic.orm.mapper;

import com.longshare.fm.otc.systemic.orm.po.BankInfoEntity;
import com.longshare.fm.otc.systemic.orm.po.BankInfoQueryBean;
import com.longshare.rest.core.dao.UnionIDMapper;

import java.util.List;

public interface BankInfoMapper extends UnionIDMapper<BankInfoEntity> {
    List<BankInfoEntity> bankInfoQuery(BankInfoQueryBean bankInfoQueryBean);
}
