package com.longshare.fm.otc.systemic.service.dto;


import com.longshare.microservice.ots.biz.core.model.common.OtcPageIn;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BankInfoListQueryIn extends OtcPageIn {

    //银行序号
    private String bankId;
    //关键字
    private String keyWord;

}
