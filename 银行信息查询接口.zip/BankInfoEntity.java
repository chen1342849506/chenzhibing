package com.longshare.fm.otc.systemic.orm.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Table;

@Getter
@Setter
@ToString
@Table(name="TBANKINFO")
public class BankInfoEntity {

    //银行序号
    private Integer bankId;
    //发行人序号
    private Integer issuerId;
    //银行代码
    private String bankCode;
    //银行名称
    private String bankName;
}
