package com.longshare.fm.otc.systemic.service.dto;


import com.longshare.fm.otc.systemic.orm.po.BankInfoEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BankInfo {
    //银行序号
    private Integer bankId;
    //发行人序号
    private Integer issuerId;
    //银行代码
    private String bankCode;
    //银行名称
    private String bankName;


    public BankInfo(BankInfoEntity entity) {
        this.bankId = entity.getBankId();
        this.issuerId = entity.getIssuerId();
        this.bankCode = entity.getBankCode();
        this.bankName = entity.getBankName();
    }
}
