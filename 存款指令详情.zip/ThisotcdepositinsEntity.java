package com.longshare.microservice.ots.biz.db.orm.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Table;

/**
* Created by Westlake
*/

@Getter
@Setter
@ToString
@Table(name = "THISOTCDEPOSITINS")
public class ThisotcdepositinsEntity {

    @Column(name = "ARCHIVE_DATE")
    private Integer archiveDate;

    @Column(name = "OTC_INS_ID")
    private Integer otcInsId;

    @Column(name = "OTC_INQ_RES_ID")
    private Integer otcInqResId;

    @Column(name = "INS_SEC_ID")
    private Integer insSecId;

    @Column(name = "INS_NEWDATE")
    private Integer insNewdate;

    @Column(name = "OTC_ORIG_INS_ID")
    private Integer otcOrigInsId;

    @Column(name = "OTC_INS_STATUS")
    private Integer otcInsStatus;

    @Column(name = "INS_PURPOSE")
    private Integer insPurpose;

    @Column(name = "PRODUCT_ID")
    private Integer productId;

    @Column(name = "UNIT_ID")
    private Integer unitId;

    @Column(name = "COMBI_ID")
    private Integer combiId;

    @Column(name = "HEAD_BANK_ID")
    private Integer headBankId;

    @Column(name = "BANK_BRANCH")
    private String bankBranch;

    @Column(name = "DEPOSIT_EXEC_TYPE")
    private Integer depositExecType;

    @Column(name = "DEPOSIT_AMT")
    private Double depositAmt;

    @Column(name = "DEPOSIT_RATE")
    private Double depositRate;

    @Column(name = "DEPOSIT_LIMIT_TIME")
    private Integer depositLimitTime;

    @Column(name = "EXPIRE_TYPE")
    private Integer expireType;

    @Column(name = "PAY_PURCHASE_DATE")
    private Integer payPurchaseDate;

    @Column(name = "WITHDRAW_DATE")
    private Integer withdrawDate;

    @Column(name = "PAYL_VALUE_DATE")
    private Integer paylValueDate;

    @Column(name = "WITHDRAW_LIMIT")
    private Integer withdrawLimit;

    @Column(name = "INTEREST_PAY_FREQ")
    private Integer interestPayFreq;

    @Column(name = "CALC_RATE_TYPE")
    private Integer calcRateType;

    @Column(name = "INS_BEGIN_DATE")
    private Integer insBeginDate;

    @Column(name = "INS_END_DATE")
    private Integer insEndDate;

    @Column(name = "CREATE_DATE")
    private Integer createDate;

    @Column(name = "CREATE_TIME")
    private Integer createTime;

    @Column(name = "DIRECT_USER")
    private Integer directUser;

    @Column(name = "REMARK")
    private String remark;


}
