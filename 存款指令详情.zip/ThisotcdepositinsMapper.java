package com.longshare.microservice.ots.biz.db.orm.mapper.auto;


import com.longshare.microservice.ots.biz.db.orm.po.ThisotcdepositinsEntity;
import com.longshare.microservice.ots.biz.db.orm.po.TotcdepositinsEntity;
import com.longshare.ots.framework.core.orm.extension.UnionIDMapper;

/**
 * Created by Westlake 
 */
public interface ThisotcdepositinsMapper extends UnionIDMapper<ThisotcdepositinsEntity> {

}
