package com.longshare.fm.otc.deposit.orm.po;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class InsInfoDetailBean {
    //场外存款询价结果序号
    private Integer otcInsId;
}