package com.longshare.fm.otc.deposit.service.dto;

import com.longshare.microservice.ots.biz.db.orm.po.ThisotcdepositinsEntity;
import com.longshare.microservice.ots.biz.db.orm.po.TotcdepositinsEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class InsInfoDetailOut {
    //场外存款指令序号
    private Integer otcInsId;
    //存款指令序号
    private Integer OtcInsResId;
    //指令证券号
    private Integer InsSecId;
    //存款指令状态
    private Integer otcInsStatus;
    //存款指令状态翻译
    private String otcInsStatusText;
    //创建日期
    private Integer createDate;
    //创建时间
    private Integer createTime;
    //产品序号
    private Integer productId;
    //产品简称
    private String productName;
    //产品代码
    private String productCode;
    //组合序号
    private Integer combiId;
    //组合名称
    private String combiName;
    //存款金额
    private Double depositAmt;
    //存款利率
    private Double depositRate;
    //存款期限
    private Integer depositLimitTime;
    //银行序号
    private Integer bankId;
    //银行名称
    private String bankName;
    //银行支行
    private String bankBranch;
    //到期类型
    private Integer expireType;
    //到期类型翻译
    private String expireTypeText;
    //缴款日期
    private Integer payPurchaseDate;
    //支取日期
    private Integer withdrawDate;
    //起息日期
    private Integer paylValueDate;
    //支取限制
    private Integer withdrawLimit;
    //支取限制翻译
    private String withdrawLimitText;
    //付息频率
    private Integer interestPayFreq;
    //付息频率翻译
    private String interestPayFreqText;
    //计息方式
    private Integer calcRateType;
    //计息方式翻译
    private String calcRateTypeText;
    //操作员序号
    private Integer userId;
    //操作员姓名
    private String userName;
    //存款执行方式
    private Integer depositExecType;
    //存款执行方式翻译
    private String depositExecTypeText;
    //开始日期
    private Integer beginDate;
    //结束日期
    private Integer endDate;
    //备注
    private String remark;
    public InsInfoDetailOut(TotcdepositinsEntity entity){
        this.otcInsId = entity.getOtcInsId();
        this.OtcInsResId = entity.getOtcInqResId();
        this.InsSecId = entity.getInsSecId();
        this.otcInsStatus = entity.getOtcInsStatus();
        this.createDate = entity.getCreateDate();
        this.createTime = entity.getCreateTime();
        this.productId = entity.getProductId();
        this.combiId = entity.getCombiId();
        this.depositAmt = entity.getDepositAmt();
        this.depositRate = entity.getDepositRate();
        this.depositLimitTime = entity.getDepositLimitTime();
        this.bankId = entity.getHeadBankId();
        this.bankBranch = entity.getBankBranch();
        this.expireType = entity.getExpireType();
        this.payPurchaseDate = entity.getPayPurchaseDate();
        this.withdrawDate = entity.getWithdrawDate();
        this.paylValueDate = entity.getPaylValueDate();
        this.withdrawLimit = entity.getWithdrawLimit();
        this.interestPayFreq = entity.getInterestPayFreq();
        this.calcRateType = entity.getCalcRateType();
        this.userId = entity.getDirectUser();
        this.depositExecType = entity.getDepositExecType();
        this.beginDate = entity.getInsBeginDate();
        this.endDate = entity.getInsEndDate();
        this.remark = entity.getRemark();
    }
    public InsInfoDetailOut(ThisotcdepositinsEntity entity){
        this.otcInsId = entity.getOtcInsId();
        this.OtcInsResId = entity.getOtcInqResId();
        this.InsSecId = entity.getInsSecId();
        this.otcInsStatus = entity.getOtcInsStatus();
        this.createDate = entity.getCreateDate();
        this.createTime = entity.getCreateTime();
        this.productId = entity.getProductId();
        this.combiId = entity.getCombiId();
        this.depositAmt = entity.getDepositAmt();
        this.depositRate = entity.getDepositRate();
        this.depositLimitTime = entity.getDepositLimitTime();
        this.bankId = entity.getHeadBankId();
        this.bankBranch = entity.getBankBranch();
        this.expireType = entity.getExpireType();
        this.payPurchaseDate = entity.getPayPurchaseDate();
        this.withdrawDate = entity.getWithdrawDate();
        this.paylValueDate = entity.getPaylValueDate();
        this.withdrawLimit = entity.getWithdrawLimit();
        this.interestPayFreq = entity.getInterestPayFreq();
        this.calcRateType = entity.getCalcRateType();
        this.userId = entity.getDirectUser();
        this.depositExecType = entity.getDepositExecType();
        this.beginDate = entity.getInsBeginDate();
        this.endDate = entity.getInsEndDate();
        this.remark = entity.getRemark();
    }
}