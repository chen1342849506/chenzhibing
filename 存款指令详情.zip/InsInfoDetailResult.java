package com.longshare.fm.otc.deposit.model.vo;

import com.longshare.fm.otc.deposit.service.dto.InsInfoDetailOut;
import com.longshare.microservice.ots.biz.core.utils.StringUtils;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class InsInfoDetailResult {
    //场外存款指令序号
    private String otcInsId;
    //场外指令结果序号
    private String otcInsResId;
    //指令证券号
    private String InsSecId;
    //场外指令状态
    private String otcInsStatus;
    //场外指令状态翻译
    private String otcInsStatusText;
    //创建日期
    private String createDate;
    //创建时间
    private String createTime;
    //产品序号
    private String productId;
    //产品简称
    private String productName;
    //产品代码
    private String productCode;
    //组合序号
    private String combiId;
    //组合名称
    private String combiName;
    //存款金额
    private String depositAmt;
    //存款利率
    private String depositRate;
    //存款期限
    private String depositLimitTime;
    //银行序号
    private String bankId;
    //银行名称
    private String bankName;
    //银行支行
    private String bankBranch;
    //到期类型
    private String expireType;
    //到期类型翻译
    private String expireTypeText;
    //缴款日期
    private String payPurchaseDate;
    //支取日期
    private String withdrawDate;
    //起息日期
    private String paylValueDate;
    //支取限制
    private String withdrawLimit;
    //支取限制翻译
    private String withdrawLimitText;
    //付息频率
    private String interestPayFreq;
    //付息频率翻译
    private String interestPayFreqText;
    //计息方式
    private String calcRateType;
    //计息方式翻译
    private String calcRateTypeText;
    //操作员序号
    private String userId;
    //操作员姓名
    private String userName;
    //存款执行方式
    private String depositExecType;
    //存款执行方式翻译
    private String depositExecTypeText;
    //开始日期
    private String beginDate;
    //结束日期
    private String endDate;
    //备注
    private String remark;
    public InsInfoDetailResult(InsInfoDetailOut insInfoDetailOut){
        this.otcInsId = StringUtils.toString(insInfoDetailOut.getOtcInsId());
        this.otcInsResId = StringUtils.toString(insInfoDetailOut.getOtcInsResId());
        this.InsSecId = StringUtils.toString(insInfoDetailOut.getInsSecId());
        this.otcInsStatus = StringUtils.toString(insInfoDetailOut.getOtcInsStatus());
        this.otcInsStatusText = insInfoDetailOut.getOtcInsStatusText();
        this.createDate = StringUtils.toString(insInfoDetailOut.getCreateDate());
        this.createTime = StringUtils.toString(insInfoDetailOut.getCreateTime());
        this.productId = StringUtils.toString(insInfoDetailOut.getProductId());
        this.productName = insInfoDetailOut.getProductName();
        this.productCode = insInfoDetailOut.getProductCode();
        this.combiId = StringUtils.toString(insInfoDetailOut.getCombiId());
        this.combiName = insInfoDetailOut.getCombiName();
        this.depositAmt = StringUtils.toString(insInfoDetailOut.getDepositAmt());
        this.depositRate = StringUtils.toString(insInfoDetailOut.getDepositRate());
        this.depositLimitTime = StringUtils.toString(insInfoDetailOut.getDepositLimitTime());
        this.bankId = StringUtils.toString(insInfoDetailOut.getBankId());
        this.bankName = insInfoDetailOut.getBankName();
        this.bankBranch = insInfoDetailOut.getBankBranch();
        this.expireType = StringUtils.toString(insInfoDetailOut.getExpireType());
        this.expireTypeText = insInfoDetailOut.getExpireTypeText();
        this.payPurchaseDate = StringUtils.toString(insInfoDetailOut.getPayPurchaseDate());
        this.withdrawDate = StringUtils.toString(insInfoDetailOut.getWithdrawDate());
        this.paylValueDate = StringUtils.toString(insInfoDetailOut.getPaylValueDate());
        this.withdrawLimit = StringUtils.toString(insInfoDetailOut.getWithdrawLimit());
        this.withdrawLimitText = insInfoDetailOut.getWithdrawLimitText();
        this.interestPayFreq = StringUtils.toString(insInfoDetailOut.getInterestPayFreq());
        this.interestPayFreqText = insInfoDetailOut.getInterestPayFreqText();
        this.calcRateType = StringUtils.toString(insInfoDetailOut.getCalcRateType());
        this.calcRateTypeText = insInfoDetailOut.getCalcRateTypeText();
        this.userId = StringUtils.toString(insInfoDetailOut.getUserId());
        this.userName = insInfoDetailOut.getUserName();
        this.depositExecType = StringUtils.toString(insInfoDetailOut.getDepositExecType());
        this.depositExecTypeText = insInfoDetailOut.getDepositExecTypeText();
        this.beginDate = StringUtils.toString(insInfoDetailOut.getBeginDate());
        this.endDate = StringUtils.toString(insInfoDetailOut.getEndDate());
        this.remark = insInfoDetailOut.getRemark();
    }
}