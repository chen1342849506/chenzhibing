package com.longshare.fm.otc.deposit.service.dto;

import com.longshare.fm.otc.deposit.orm.po.InsInfoDetailBean;
import com.longshare.microservice.ots.biz.core.model.common.OtcBaseIn;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class InsInfoDetailIn extends OtcBaseIn{
    //场外存款指令序号
    private Integer otcInsId;

    public InsInfoDetailBean toBean(){
        InsInfoDetailBean insInfoDetailBean = new InsInfoDetailBean();
        insInfoDetailBean.setOtcInsId(this.otcInsId);
        return insInfoDetailBean;
    }

}