package com.longshare.fm.otc.deposit.model.vo;

import com.longshare.fm.otc.deposit.service.dto.InsInfoDetailIn;
import com.longshare.microservice.ots.biz.core.model.common.OtcBaseParam;
import com.longshare.microservice.ots.biz.core.utils.NumericHelper;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class InsInfoDetailParam extends OtcBaseParam{
    @ApiModelProperty("场外存款指令序号")
    //场外存款询价结果序号
    @NotNull(message = "场外存款指令序号不能为空")
    private String otcInsId;

    public InsInfoDetailIn paramToIn(String userId){
        InsInfoDetailIn insInfoDetailIn = new InsInfoDetailIn();
        insInfoDetailIn.setOtcInsId(NumericHelper.toInteger(this.otcInsId));
        insInfoDetailIn.setUserId(NumericHelper.toInteger(userId));
        return insInfoDetailIn;
    }

}